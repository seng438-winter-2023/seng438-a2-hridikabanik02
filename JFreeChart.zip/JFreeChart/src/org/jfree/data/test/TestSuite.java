package org.jfree.data.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	RangeTest.class,
	DataUtilitiesTest.class
	})

public class TestSuite {
	
	
}
